CREATE TRIGGER BOOKS_ID_TRG
BEFORE INSERT
  ON BOOK
FOR EACH ROW
  begin
if :new.id is null then
select ACTREADER.BOOK_SEQ.NEXTVAL into :new.id from dual;
end if;
end;
/
